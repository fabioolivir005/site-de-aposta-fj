const mongoose = require('mongoose');
const dotenv = require('dotenv');
const Admin = require('./models/Admin');

dotenv.config();
mongoose.connect(process.env.MONGO_URI).then(async () => {
  const existing = await Admin.findOne({ username: 'admin' });
  if (!existing) {
    await Admin.create({ username: 'admin', password: 'admin123' });
    console.log('Admin criado: admin / admin123');
  } else {
    console.log('Admin já existe');
  }
  mongoose.disconnect();
});