const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const Admin = require('../models/Admin');
const User = require('../models/User');
const Settings = require('../models/Settings');

router.post('/login', async (req, res) => {
  const { username, password } = req.body;
  const admin = await Admin.findOne({ username });
  if (!admin || !(await admin.comparePassword(password))) {
    return res.status(401).json({ error: 'Credenciais inválidas' });
  }
  const token = jwt.sign({ id: admin._id, role: 'admin' }, process.env.JWT_SECRET);
  res.json({ token });
});

router.get('/users', async (req, res) => {
  const users = await User.find().select('-password');
  res.json(users);
});

router.patch('/saldo/:userId', async (req, res) => {
  const { userId } = req.params;
  const { amount } = req.body;
  const user = await User.findById(userId);
  if (!user) return res.status(404).json({ error: 'Usuário não encontrado' });
  user.balance += amount;
  await user.save();
  res.json({ balance: user.balance });
});

router.delete('/user/:userId', async (req, res) => {
  await User.findByIdAndDelete(req.params.userId);
  res.json({ message: 'Usuário banido com sucesso' });
});

router.get('/history/:userId', async (req, res) => {
  const user = await User.findById(req.params.userId);
  if (!user) return res.status(404).json({ error: 'Usuário não encontrado' });
  res.json(user.betHistory);
});

router.get('/settings', async (req, res) => {
  let settings = await Settings.findOne();
  if (!settings) settings = await Settings.create({});
  res.json(settings);
});

router.patch('/settings', async (req, res) => {
  let settings = await Settings.findOne();
  if (!settings) settings = await Settings.create({});
  Object.assign(settings, req.body);
  await settings.save();
  res.json(settings);
});

module.exports = router;