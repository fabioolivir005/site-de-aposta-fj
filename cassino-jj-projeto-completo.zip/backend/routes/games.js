const express = require('express');
const router = express.Router();
const User = require('../models/User');
const Settings = require('../models/Settings');

const addHistory = async (userId, game, result, amount, win) => {
  const user = await User.findById(userId);
  if (!user) return;
  user.betHistory.push({ game, result, amount, win });
  await user.save();
};

router.post('/dice', async (req, res) => {
  const { userId, amount } = req.body;
  const settings = await Settings.findOne();
  if (!settings?.gamesEnabled?.dice) return res.status(403).send("Jogo desativado.");

  const roll = Math.floor(Math.random() * 6) + 1;
  const win = roll >= 4;
  const user = await User.findById(userId);
  if (!user || user.balance < amount) return res.status(400).send("Saldo insuficiente.");
  user.balance += win ? amount : -amount;
  await user.save();
  await addHistory(userId, 'dice', `Rolou ${roll}`, amount, win);
  res.json({ result: roll, win, balance: user.balance });
});

router.post('/coin', async (req, res) => {
  const { userId, amount, choice } = req.body;
  const settings = await Settings.findOne();
  if (!settings?.gamesEnabled?.coin) return res.status(403).send("Jogo desativado.");

  const flip = Math.random() < 0.5 ? 'cara' : 'coroa';
  const win = flip === choice;
  const user = await User.findById(userId);
  if (!user || user.balance < amount) return res.status(400).send("Saldo insuficiente.");
  user.balance += win ? amount : -amount;
  await user.save();
  await addHistory(userId, 'coin', `Deu ${flip}`, amount, win);
  res.json({ result: flip, win, balance: user.balance });
});

module.exports = router;