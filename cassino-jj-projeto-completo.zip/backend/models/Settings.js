const mongoose = require('mongoose');

const settingsSchema = new mongoose.Schema({
  siteName: { type: String, default: "Cassino JJ" },
  primaryColor: { type: String, default: "#0066ff" },
  theme: { type: String, default: "dark" },
  welcomeBonus: { type: Number, default: 0 },
  defaultBetAmount: { type: Number, default: 10 },
  allowRegister: { type: Boolean, default: true },
  promoMessage: { type: String, default: "" },
  gamesEnabled: {
    dice: { type: Boolean, default: true },
    coin: { type: Boolean, default: true }
  }
});

module.exports = mongoose.model("Settings", settingsSchema);